﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGUtilities
{
    public class Constants
    {
        public static double Epsilon = 1e-7;
    }
}
